# Instructions for Paradigm Doctor Slider plugin
## Add your own doctor images with the same names as existing images and overwrite them.
## Add any applicable background or regular images and modify in shortcode.php and stylesheet as needed
## Modify any Doctor content in the javascript near the top, everything else should function correctly when the shortcode of '[paradigm_doctor_slider]' is used