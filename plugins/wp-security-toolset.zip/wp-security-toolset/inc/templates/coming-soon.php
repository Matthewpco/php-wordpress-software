<?php
/**
 * Template Name: Coming Soon
 */
?>

<style>
body {
    margin: 0;
}
</style>

<div style="background-color: #004d9f; color: white; padding: 20px; text-align: center;">
    <h1>Opening Soon</h1>
</div>

<div style="padding: 20px; text-align: center;">
    <h2>COMING SOON</h2>
    <h3>Winter 2024</h3>
    <p>For more details call</p>
    <p><a href="tel:4254777723">425-477-7723</a></p>
</div>

