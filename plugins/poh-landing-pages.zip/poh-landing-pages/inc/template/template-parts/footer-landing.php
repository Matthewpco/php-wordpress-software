    <!-- Begin footer section -->
    <footer id="footer-section" class="text-align-center">
            <span>© 2023, Optimum Oral Surgery Group. All rights reserved.</span>
    </footer>

    <?php wp_footer(); ?>

	</body>
</html>