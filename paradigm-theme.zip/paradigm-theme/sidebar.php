<?php
// sidebar.php
?>

<!-- 1/3 Set Up -->
<div class="one-third-column">
   <?php echo do_shortcode('[paradigm_forms_sidebar] '); ?>
</div>