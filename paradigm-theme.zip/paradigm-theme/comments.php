<?php
// sidebar.php

// This is an empty file
// No content is required in this file
// You can leave it completely blank
